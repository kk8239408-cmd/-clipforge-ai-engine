CLIPFORGE FONT LIBRARY — CURATED PACK

01_Core_Captions
- Best practical choices for readable short-form captions:
  Montserrat Black / Bold / SemiBold / Medium / Regular
  League Spartan Bold
  Arial Narrow Bold
- ExtraBoldItalic is an accent option, not the default.

02_Display_and_Accent
- Obelix Pro Bold / Bold Italic: punchy, comic/sports emphasis.
- Designer, Magazine Letter, Zenzai Itacha: occasional stylized accents.
- Avoid using decorative fonts for long captions because readability can suffer.

03_Fallback
- Arial Narrow Regular.

04_License_Check_Before_Public_Commercial_Use
- Devil Candle files explicitly say PERSONAL USE ONLY. Do not ship/use these in a public or commercial CLIPFORGE service unless the font owner grants commercial permission.
- The supplied Montserrat OFL.txt covers Montserrat. Keep it with the Montserrat files.
- For Obelix Pro, Designer, Magazine Letter, Zenzai Itacha, and Arial Narrow, verify each font's own license before bundling them in a public/commercial service. The supplied README only says to check each font's individual license; it does not prove commercial rights.

Duplicates / redundant formats removed from this curated pack:
- Montserrat OTF copies where a matching TTF face was supplied.
- League Spartan EOT, SVG, WOFF, and WOFF2 copies; TTF retained.
- Duplicate/near-duplicate Zenzai variants: Itache and Itachi not included; Itacha selected.
- Unneeded thin/light/italic Montserrat variants omitted from the practical caption set.

Automatic font selection recommendation:
- Default dialogue captions: Montserrat Bold or SemiBold.
- Loud/high-energy moments: Montserrat Black or League Spartan Bold.
- Narrow layouts: Arial Narrow Bold.
- Comic/sports punchline emphasis: Obelix Pro Bold.
- Decorative title cards only: Designer / Magazine Letter / Zenzai Itacha.
